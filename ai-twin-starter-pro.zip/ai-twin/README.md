# Chat AI Twin — Pro Starter

**Функции:**
- Брандинг (лого текст, цветове, tagline) чрез env в `config.js`.
- Бутон **Копирай** към всеки отговор.
- Rate limiting (по IP, in-memory) — `RATE_LIMIT_MAX`/мин.
- Аналитика (по избор) с Plausible — `NEXT_PUBLIC_PLAUSIBLE_DOMAIN`.
- Цени/планове със Stripe **Payment Links** (без бекенд) — виж `/pricing`.

## Бърз старт (локално)
```bash
npm install
export OPENAI_API_KEY=твоят_ключ
npm run dev
```

Отвори: http://localhost:3000

## Деплой на Vercel
1. Качи кода в GitHub и създай проект във Vercel.
2. Добави **Environment Variables**:
   - `OPENAI_API_KEY` = <твоят ключ>
   - `OPENAI_MODEL` = gpt-4o-mini (по избор)
   - `NEXT_PUBLIC_BRAND_NAME` / `NEXT_PUBLIC_BRAND_TAGLINE` / `NEXT_PUBLIC_BRAND_PRIMARY` / `NEXT_PUBLIC_BRAND_LOGOTEXT`
   - `NEXT_PUBLIC_WEBSITE` (по избор)
   - `NEXT_PUBLIC_TWITTER` (по избор)
   - `NEXT_PUBLIC_PLAUSIBLE_DOMAIN` (по избор, за аналитика)
   - `NEXT_PUBLIC_STRIPE_STARTER_LINK` (Payment Link URL)
   - `NEXT_PUBLIC_STRIPE_PRO_LINK` (Payment Link URL)
   - `NEXT_PUBLIC_STRIPE_BUSINESS_LINK` (Payment Link URL)
   - `RATE_LIMIT_MAX` (напр. 20)
3. Deploy и отвори `/pricing` за бутоните към Stripe.

## Забележки
- Rate limiter-ът е in-memory и подходящ за начало/една инстанция. За продъкшън помисли за Redis/Upstash.
- Stripe Payment Links са **най-бързият** начин да приемаш плащания без сървърни ключове.
- За по-сложни планове (webhooks, лицензиране) — добави сървърно приложение и база.
