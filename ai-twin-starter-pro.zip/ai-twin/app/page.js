"use client";
import { useState } from "react";
import Link from "next/link";
import BRAND from "./../config";

export default function Home() {
  const [messages, setMessages] = useState([
    { role: "assistant", content: "Здрасти! Аз съм твоят Чат AI Twin. С какво да помогна?" }
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);

  async function copyToClipboard(text) {
    try {
      await navigator.clipboard.writeText(text);
      alert("Копирано в клипборда!");
    } catch (e) {
      console.error(e);
    }
  }

  async function sendMessage(e) {
    e.preventDefault();
    const content = input.trim();
    if (!content) return;
    const newMessages = [...messages, { role: "user", content }];
    setMessages(newMessages);
    setInput("");
    setLoading(true);

    const res = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ messages: newMessages }),
    });

    if (!res.ok) {
      const err = await res.text();
      setMessages([...newMessages, { role: "assistant", content: "⚠️ Грешка: " + err }]);
      setLoading(false);
      return;
    }

    const data = await res.json();
    setMessages([...newMessages, { role: "assistant", content: data.reply }]);
    setLoading(false);
  }

  return (
    <main style={{ maxWidth: 960, margin: "16px auto", padding: 16 }}>
      <nav style={{ display: "flex", gap: 12, justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
        <div style={{ display: "flex", gap: 8, alignItems: "baseline" }}>
          <div style={{ fontWeight: 800, color: BRAND.primary }}>{BRAND.logoText}</div>
          <div style={{ color: "#666" }}>{BRAND.name}</div>
        </div>
        <div style={{ display: "flex", gap: 12 }}>
          <Link href="/pricing">Цени</Link>
          <a href={process.env.NEXT_PUBLIC_WEBSITE || "#"} target="_blank" rel="noreferrer">Уебсайт</a>
        </div>
      </nav>

      <div style={{ background: "#fff", border: "1px solid #e5e7eb", borderRadius: 12, padding: 16, minHeight: 420 }}>
        {messages.map((m, i) => (
          <div key={i} style={{ display: "flex", justifyContent: m.role === "user" ? "flex-end" : "flex-start", marginBottom: 10 }}>
            <div style={{ 
              background: m.role === "user" ? "#e0f2fe" : "#f3f4f6", 
              padding: "10px 12px", 
              borderRadius: 12, 
              maxWidth: "85%", 
              whiteSpace: "pre-wrap",
              position: "relative"
            }}>
              {m.content}
              {m.role === "assistant" && (
                <button
                  onClick={() => copyToClipboard(m.content)}
                  style={{
                    position: "absolute",
                    right: 8,
                    bottom: 8,
                    border: "1px solid #d1d5db",
                    background: "#fff",
                    borderRadius: 8,
                    fontSize: 12,
                    padding: "2px 6px",
                    cursor: "pointer"
                  }}
                  title="Копирай"
                >
                  Копирай
                </button>
              )}
            </div>
          </div>
        ))}
        {loading && (
          <div style={{ color: "#666", fontSize: 14 }}>Мисля…</div>
        )}
      </div>

      <form onSubmit={sendMessage} style={{ marginTop: 12, display: "flex", gap: 8 }}>
        <textarea
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Напиши съобщение…"
          rows={2}
          style={{ flex: 1, padding: 10, borderRadius: 10, border: "1px solid #d1d5db", resize: "vertical" }}
        />
        <button 
          type="submit" 
          disabled={loading}
          style={{ padding: "0 16px", borderRadius: 10, border: "1px solid #0ea5e9", background: loading ? "#bae6fd" : "#0ea5e9", color: "#fff", fontWeight: 600 }}
        >
          {loading ? "Изпращам…" : "Изпрати"}
        </button>
      </form>

      <div style={{ marginTop: 10, fontSize: 12, color: "#666" }}>
        <p>Системният стил е персонализируем в <code>/app/api/chat/route.js</code>. Добави твои материали (RAG) по-късно.</p>
      </div>
    </main>
  );
}
