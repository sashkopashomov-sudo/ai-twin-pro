import BRAND from "../config";
export const metadata = {
  title: BRAND.name,
  description: BRAND.tagline,
};

export default function RootLayout({ children }) {
  const plausibleDomain = process.env.NEXT_PUBLIC_PLAUSIBLE_DOMAIN;
  return (
    <html lang="bg">
      <head>
        {plausibleDomain ? (
          <script defer data-domain={plausibleDomain} src="https://plausible.io/js/script.js"></script>
        ) : null}
      </head>
      <body style={{ fontFamily: 'system-ui, Arial, sans-serif', background: '#f7f7f8', color: '#111' }}>
        <header style={{ maxWidth: 960, margin: '0 auto', padding: '16px 16px 0 16px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <div style={{ fontWeight: 800, fontSize: 20, letterSpacing: 0.4, color: BRAND.primary }}>{BRAND.logoText}</div>
            <div style={{ color: '#666' }}>{BRAND.tagline}</div>
          </div>
        </header>
        {children}
        <footer style={{ maxWidth: 960, margin: '24px auto', padding: '0 16px', fontSize: 12, color: '#666' }}>
          <div>© {new Date().getFullYear()} {BRAND.name}. Всички права запазени.</div>
        </footer>
      </body>
    </html>
  );
}
