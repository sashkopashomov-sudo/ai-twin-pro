"use client";
import BRAND, { LINKS } from "../config";
import Link from "next/link";

const plans = [
  { name: "Starter", price: "$9 / месец", desc: "Основни чатове / месец", link: LINKS.starter },
  { name: "Pro", price: "$29 / месец", desc: "Повече чатове + приоритет", link: LINKS.pro },
  { name: "Business", price: "$199+ / месец", desc: "Бранд, SLA и персонализация", link: LINKS.business },
];

export default function Pricing() {
  return (
    <main style={{ maxWidth: 960, margin: "24px auto", padding: 16 }}>
      <h1 style={{ marginBottom: 8 }}>Планове и цени</h1>
      <p style={{ color: "#555", marginBottom: 20 }}>Избери план и започни с {BRAND.name} за минути.</p>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))", gap: 16 }}>
        {plans.map((p) => (
          <div key={p.name} style={{ background: "#fff", border: "1px solid #e5e7eb", borderRadius: 12, padding: 16 }}>
            <div style={{ fontWeight: 700, fontSize: 18 }}>{p.name}</div>
            <div style={{ fontSize: 24, marginTop: 8 }}>{p.price}</div>
            <div style={{ color: "#666", marginTop: 6 }}>{p.desc}</div>
            <a
              href={p.link || "#"}
              target="_blank"
              rel="noreferrer"
              style={{ display: "inline-block", marginTop: 12, padding: "8px 12px", borderRadius: 10, border: "1px solid #0ea5e9", background: "#0ea5e9", color: "#fff" }}
            >
              {p.link ? "Купи" : "Скоро"}
            </a>
          </div>
        ))}
      </div>
      <div style={{ marginTop: 16, fontSize: 14 }}>
        <Link href="/">← Към чата</Link>
      </div>
    </main>
  );
}
