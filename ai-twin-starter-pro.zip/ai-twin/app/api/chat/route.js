import OpenAI from "openai";

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// Simple in-memory rate limiter (per Vercel instance)
const WINDOW_MS = 60 * 1000; // 1 minute
const MAX_REQ = parseInt(process.env.RATE_LIMIT_MAX || "20", 10);
const store = global._rateStore || new Map();
if (!global._rateStore) global._rateStore = store;

function getIp(req) {
  try {
    const hdr = req.headers.get("x-forwarded-for") || "";
    return hdr.split(",")[0]?.trim() || "unknown";
  } catch {
    return "unknown";
  }
}

function isRateLimited(ip) {
  const now = Date.now();
  const rec = store.get(ip) || { count: 0, start: now };
  if (now - rec.start > WINDOW_MS) {
    store.set(ip, { count: 1, start: now });
    return false;
  }
  rec.count += 1;
  store.set(ip, rec);
  return rec.count > MAX_REQ;
}

export async function POST(req) {
  try {
    const ip = getIp(req);
    if (isRateLimited(ip)) {
      return new Response("Rate limit exceeded. Опитайте след малко.", { status: 429 });
    }

    const { messages } = await req.json();
    const last = messages?.[messages.length - 1]?.content || "";
    if (last.length > 4000) {
      return new Response("Съобщението е твърде дълго (макс ~4000 символа).", { status: 400 });
    }

    const systemPrompt = [
      "Ти си Чат AI Twin на Потребителя.",
      "Говориш на български: кратко, практично, приятелски.",
      "Приоритети: (1) точност, (2) яснота, (3) тон като потребителя.",
      "Когато не си сигурен, казваш какво липсва и предлагаш безопасна алтернатива.",
      "Не измисляй факти; ако темата е чувствителна (право/медицина/финанси), давай обща инфо и насочвай към специалист.",
      "Структура: мини-обобщение → стъпки/списък → при нужда пример/шаблон → следващи действия."
    ].join("\n");

    const completion = await client.chat.completions.create({
      model: process.env.OPENAI_MODEL || "gpt-4o-mini",
      temperature: 0.6,
      messages: [
        { role: "system", content: systemPrompt },
        ...messages,
      ],
    });

    const reply = completion.choices?.[0]?.message?.content ?? "Изникна непредвиден проблем. Опитай пак.";
    return new Response(JSON.stringify({ reply }), { headers: { "Content-Type": "application/json" } });
  } catch (err) {
    console.error(err);
    return new Response(err?.message || "Server error", { status: 500 });
  }
}
