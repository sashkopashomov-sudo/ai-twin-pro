// Edit your brand & links here
const BRAND = {
  name: process.env.NEXT_PUBLIC_BRAND_NAME || "Chat AI Twin",
  tagline: process.env.NEXT_PUBLIC_BRAND_TAGLINE || "Вашият персонален AI близнак",
  primary: process.env.NEXT_PUBLIC_BRAND_PRIMARY || "#0ea5e9",
  logoText: process.env.NEXT_PUBLIC_BRAND_LOGOTEXT || "AI•Twin",
  twitter: process.env.NEXT_PUBLIC_TWITTER || "",
  website: process.env.NEXT_PUBLIC_WEBSITE || "",
};

export const LINKS = {
  // Optional Stripe Payment Links (no server needed)
  starter: process.env.NEXT_PUBLIC_STRIPE_STARTER_LINK || "",
  pro: process.env.NEXT_PUBLIC_STRIPE_PRO_LINK || "",
  business: process.env.NEXT_PUBLIC_STRIPE_BUSINESS_LINK || "",
};

export default BRAND;
